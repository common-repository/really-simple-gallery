<?php
include("includes/graphics.class.php");

if(!$_GET["image"])
  echo "PLEASE PROVIDE A IMAGE IN URL";
else{

    $size = Graphics::getSize($_GET["image"]); // RETURNS ARRAY - 0 -> width 1 -> height
    $effects = $_GET["effects"];
    $width = (isset($_GET["width"]) ? $_GET["width"] : $size[0]);
	$old = Graphics::createFrom($_GET["image"]); // RETURNS A GD IMAGE OF A URL
	

	$image = new Graphics($size[0],$size[1]); // CREATE A BLANK IMAGE WE CAN CHANGE
	$image->addImage($old,0,0,$size[0],$size[1],100);
	$image->setHeader("png");
	
	// PERFORM EFFECTS HERE
	$image->resize($width);
	if(isset($effects)){
	   $effect = explode(",",$effects);
	   foreach($effect as $apply){
		  switch ($apply) {
			case "mono":
                $image->monoDither();
				break;
            case "wave":
                $image->wave(10);
                break;
			case "edge":
				$image->edgeDetect();
				break;
			case "pixel":
				$image->pixelize(5);
				break;
			case "gray":
				$image->toGrayScale();
				break;
		  } 
	   }
	}
	
    $image->show("png");
}
?>